-- AlterTable
ALTER TABLE `roles_permisos` ADD COLUMN `descripcion` VARCHAR(191) NULL;
