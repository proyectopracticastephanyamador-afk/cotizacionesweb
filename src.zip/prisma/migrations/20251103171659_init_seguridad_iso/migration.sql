-- AlterTable
ALTER TABLE `permisos` ADD COLUMN `descripcion` VARCHAR(191) NULL;
