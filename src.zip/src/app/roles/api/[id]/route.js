import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function PATCH(req, { params }) {
  const { id } = params
  const body = await req.json()
  const actualizado = await prisma.rol.update({
    where: { id: Number(id) },
    data: {
      nombre: body.nombre,
      descripcion: body.descripcion || null,
      estado: body.estado || "ACTIVO",
    },
  })
  return NextResponse.json(actualizado)
}

export async function DELETE(_, { params }) {
  const { id } = params
  await prisma.rol.delete({ where: { id: Number(id) } })
  return NextResponse.json({ ok: true })
}
