import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  const roles = await prisma.rol.findMany({ orderBy: { id: "asc" } })
  return NextResponse.json(roles)
}

export async function POST(req) {
  const body = await req.json()
  const nuevo = await prisma.rol.create({
    data: {
      nombre: body.nombre,
      descripcion: body.descripcion || null,
      estado: "ACTIVO",
    },
  })
  return NextResponse.json(nuevo)
}
